package edu.cmu.cs;

public class Main {

    public static Map makeTestMap() {
        Map m = new Map();

        m = m.put("A_", 1);
        m = m.put("B@", 2);
        m = m.put("C!", 3);
        return m;
    }

    public static void main(String[] args) {
        // TESTING PUT
        System.out.println("Testing put()…");
        Map m = makeTestMap();
        System.out.println("Initial map: " + m);

        System.out.println("Replacing B@ and C!…");
        m = m.put("B@", 42);
        m = m.put("C!", 43);
        System.out.println("Maps after change: " + m);
        System.out.println("Correct state after change is map {A_ => 1, B@ => 42, C! => 43}");
    }
}
