package edu.cmu.cs.glacier.useraccounts;

/**
 * Created by mcoblenz on 7/5/16.
 */
public class Superuser extends User {
    public Superuser(String username, String passwordHash, int userID, int groupID, String[] authorizedFiles) {
        super(username, passwordHash, userID, groupID, authorizedFiles);
    }

    public boolean canChangeAllPasswords() {
        return true;
    }
}
