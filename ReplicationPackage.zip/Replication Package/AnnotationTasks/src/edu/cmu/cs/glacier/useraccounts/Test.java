package edu.cmu.cs.glacier.useraccounts;

/**
 * Created by mcoblenz on 7/15/16.
 */
public class Test {
    public static void main(String[] args) {
        WebServer w = new WebServer();

        // Should succeed
        FileRequest r1 = new FileRequest("root", "password", "RootUserBankAccounts.txt");
        w.handleRequest(r1);

        // Should fail
        FileRequest r2 = new FileRequest("root", "wrongPassword", "RootUserBankAccounts.txt");
        w.handleRequest(r2);

        // Should fail
        FileRequest r3 = new FileRequest("root", "password", "bogusFile.txt");
        w.handleRequest(r3);
    }
}
