package edu.cmu.cs.glacier.useraccounts;

/**
 * Created by mcoblenz on 7/15/16.
 */
public class FileRequest implements Request {
    String username;
    String passwordHash;
    String requestedFile;

    public FileRequest(String username, String passwordHash, String requestedFile) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.requestedFile = requestedFile;
    }

    public void execute(Accounts a) {
        // Look up the username and passwordHash to make sure the account exists. If it does,
        // check to make sure the user has access to the specified file. If so, print "Access granted."
        // Otherwise, print "Access denied."

        // TODO: do security checks before granting access.
        System.out.println("Access granted.");
    }
}
