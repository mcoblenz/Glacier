package edu.cmu.cs.glacier.useraccounts;

/**
 * A Request represents a request from a client for a task that the web server should do.
 * Requests execute with the account information from the server, but should not change the account information.
 */
public interface Request {
    public void execute(Accounts a);
}
