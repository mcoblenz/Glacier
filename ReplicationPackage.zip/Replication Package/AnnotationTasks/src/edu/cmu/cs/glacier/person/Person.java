package edu.cmu.cs.glacier.person;

/**
 * Created by mcoblenz on 7/7/16.
 */
public class Person {
    String name;
    Address address;

    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }
}
