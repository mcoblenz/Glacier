package edu.cmu.cs.glacier.person;

/**
 * Address represents the address of a house in the US.
 */
public class Address {
    int houseNumber;
    String street;
    String city;
    String state;
    int zip;

    public Address(int houseNumber, String street, String city, String state, int zip) {
        this.houseNumber = houseNumber;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }

    public int getHouseNumber() {
        return houseNumber;
    }

    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public int getZip() {
        return zip;
    }
}
