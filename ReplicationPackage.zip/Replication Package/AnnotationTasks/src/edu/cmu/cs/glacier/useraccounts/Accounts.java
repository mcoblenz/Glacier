package edu.cmu.cs.glacier.useraccounts;

/**
 * Created by mcoblenz on 7/5/16.
 *
 * This class represents all the user accounts that can log in to a computer system.
 * Various clients need access to account information, but we want to make sure that the account information
 * isn't modified accidentally, so it needs to be immutable.
 */
public class Accounts {
    User [] users;

    public Accounts(User [] users) {
        this.users = users;
    }

    public User [] getUsers() {
        return users;
    }
}