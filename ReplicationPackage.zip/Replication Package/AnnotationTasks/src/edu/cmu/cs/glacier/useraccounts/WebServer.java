package edu.cmu.cs.glacier.useraccounts;

/**
 * A WebServer represents a web server that handles requests. Some of the functionality of the web server is not yet implemented.
 */
public class WebServer {
    private Accounts accounts;

    WebServer() {
        String[] files = {"RootUserBankAccounts.txt"};
        User rootUser = new Superuser("root", "password", 1, 1, files);
        User[] users = {rootUser};
        accounts = new Accounts(users);
    }


    public void handleRequest(Request r) {
        r.execute(accounts);
    }
}
